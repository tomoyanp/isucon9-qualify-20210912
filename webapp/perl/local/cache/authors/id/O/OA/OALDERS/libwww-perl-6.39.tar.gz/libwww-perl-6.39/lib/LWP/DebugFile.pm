package LWP::DebugFile;

our $VERSION = '6.39';

# legacy stub

1;
